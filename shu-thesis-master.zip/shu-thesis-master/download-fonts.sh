wget http://zhaok-data.oss-cn-shanghai.aliyuncs.com/fonts/simhei.ttf
wget http://zhaok-data.oss-cn-shanghai.aliyuncs.com/fonts/simsun.ttc
