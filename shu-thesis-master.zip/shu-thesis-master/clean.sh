rm -rf tmp
rm *.log
rm shu-thesis.pdf
rm *.dvi
rm *.bbl
rm *.brf
rm *.out
rm *.aux
rm *.blg
rm *.gz
rm *.toc
